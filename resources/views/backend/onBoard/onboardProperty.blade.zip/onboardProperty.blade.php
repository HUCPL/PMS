@extends('backend.layout.main')
@push('title')
    <title>Admin|onBoard Property</title>
  
    <!-- include summernote css/js -->
    {{-- <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote.css" rel="stylesheet"> --}}
    {{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css"> --}}
@endpush
<style>
  .label {
    padding: 4px 6px;
    line-height: 190%;
    outline-style: none;
    transition: all .6s;
  }  
  .hiddenCB input[type="checkbox"],
  .hiddenCB input[type="radio"] {
    display: none;
  }

  .label {
    cursor: pointer;
    color:#8592A3;
    border: 1px solid #8592A3;
    border-radius:5px;
    padding-left:20px;
    padding-right:20px;
    margin-top: 1%;
  }

  .hiddenCB input[type="checkbox"]+label:hover{
    /* background: #696CFF;*/
    background: #D61B1A;
    border:none;
    color:white;
  }

  .hiddenCB input[type="checkbox"]:checked+label {
    /* background: #696CFF; */
    background: #D61B1A;
    border:none;
    color:white;
  }

  .hiddenCB input[type="checkbox"]:checked+label:hover{
    /* background: #696CFF; */
    background: #D61B1A;
    border:none;
    color:white;
  }
  .bootstrap-tagsinput .tag 
  {
    background: #D61B1A !important;
    border-color: #D61B1A !important;
  }
  .scrl::-webkit-scrollbar {
    width: 4px;
  }
  
  .scrl::-webkit-scrollbar-track{
    box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    border-radius:10px; 
  }
  
  .scrl::-webkit-scrollbar-thumb {
    /* background-color: #696CFF; */
    background-color: #D61B1A;
    border-radius:10px; 
    /* outline: 1px solid rgb(21, 73, 124); */
  }
  .legendFormSubBTN
  {
     margin:0 !important;
  }
</style>
@section('content-wrapper')
<div class="content-wrapper">
    <!-- Content -->
    
 <!-- Include jQuery (required by Summernote) -->
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

 <!-- Include Summernote JS -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote.js"></script>

    <div class="container-xxl flex-grow-1 container-p-y">
        <!-- Basic -->
        {{-- <div class="col-md-12">
           <div class="card mb-4"> --}}
            <div class="row">
              <!-- Basic -->
              <div class="col-md-12">  
              <div class="card mb-4" style="overflow:scroll; -">
                  {{-- <div class="d-flex p-4 justify-content-start">
                        <h5 class="card-header">Users Lists</h5>
                  </div> --}}
                  <div class="d-flex p-4 justify-content-end" style="width: 88%;
                                                                                  margin: 0px auto;
                                                                                  padding-right: 0px !important;">
                          @if (Auth::user()->role_as == 10) 
                             <a href="{{ route('propertyOnBoardList') }}" class="btn btn-primary" >onBoard List</a>
                          @elseif (Auth::user()->role_as == 5)
                             <a href="{{ route('propertyList') }}" class="btn btn-primary" >onBoard List</a>
                          @endif
                  </div>
                  @if (Auth::user()->role_as == 10)  
                  <form class="" action="{{ route('addPropertiesOnBoard') }}" method="post" enctype="multipart/form-data">
                    @csrf
                  @elseif (Auth::user()->role_as == 5)
                  <form class="" action="{{ route('saveProperty') }}" method="post" enctype="multipart/form-data">
                    @csrf
                  @endif
                    <div class="legendForm card-body demo-vertical-spacing demo-only-element">
                      <legend><b style="font-size:0.75rem"><i class="fa-regular fa-building"></i> PROPERTY </b> </legend> 
                      <div class="row">
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <div class="d-flex">
                              
                            </div>
                            <label for="propertyName" class="form-label">Property Name </label>
                            <input
                              class="form-control"
                              type="text"
                              id="propertyName"
                              name="propertyname"
                              value=""
                              autofocus
                              required
                            />
                           
                          </div>
                          <div class="mb-3 col-md-6 InputeFlexToChangeFields position-relative">
                          @if (Auth::user()->role_as==10)
                            <a class="btn btn-primary" style="position: absolute;
                              right: 16px;
                              z-index: 9;
                              height: 26px;
                              line-height: 12px;
                              color:white;
                              font-size: 13px;"  data-bs-toggle="modal" data-bs-target="#modalCenter" >Add</a>
                            @endif
                            <label for="propcats" class="form-label">Property Type</label>
                            <select id="propcats" class="select2 form-select propcat position-relative"  name="category"  required>
                              
                              @if ($categoriesDetails->isNotEmpty())
                                <option value="">No Property Type</option>
                              @foreach ($categoriesDetails as $categoriesnames)     
                                <option value="{{ $categoriesnames->category_id }}">{{ $categoriesnames->category_name }}</option>
                              @endforeach
                              @else     
                              <option value="">No Property Type</option>
                              @endif
                            </select>
                          </div>
                          @if (Auth::user()->role_as == 10)
                          <div class="mb-3   col-md-6 InputeFlexToChangeFields position-relative">
                            <a class="btn btn-primary" style="position:absolute;right: 16px;
                              z-index: 9;
                              height: 26px;
                              line-height: 12px;
                              color:white;
                              font-size: 13px;" data-bs-toggle="modal"
                            data-bs-target="#largeModal">Add</a>
                              
                              <label for="propcats" class="form-label">Owner Name</label>
                              <select  class="select2 form-select propcat"  name="owner"  required>
                                
                                @if ($onwerDetails->isNotEmpty())
                                  <option value="">No Owner</option>
                                @foreach ($onwerDetails as $ownernames)     
                                  <option value="{{ $ownernames->id }}">{{ $ownernames->name }}</option>
                                @endforeach
                                @else     
                                <option value="">First Add Owner Details</option>
                                @endif
                              </select>
                          </div>
                          <input type="hidden" id="oowner" value="{{ Auth::user()->role_as }}">
                          @elseif (Auth::user()->role_as == 5)
                              <input type="hidden" name="owner"  value="{{ Auth::Id()}}">
                              <input type="hidden" id="oowner" value="{{ Auth::user()->role_as }}">
                          @endif
                          
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="propertyAddress" class="form-label">Address </label>
                            <input
                              class="form-control"
                              type="text"
                              id="propertyAddress"
                              name="propertyAddress"
                              value=""
                              autofocus
                              required
                            />
                          </div>
                        
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="city" class="form-label">Country</label>
                            {{-- <input
                              class="form-control"
                              type="text"
                              id="countries"
                              name="country"
                              value=""
                              autofocus
                              required
                            /> --}}
                            <select  id="countries" class="form-control chosen-select" name="country">
                              <option value="">Select Country</option>
                            </select>
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="State" class="form-label">State</label>
                            {{-- <input
                              class="form-control"
                              type="text"
                              id="State"
                              name="state"
                              value=""
                              autofocus
                              required
                            /> --}}
                            <select id="states" class="form-control chosen-select"  name="state">
                              <option value="">Select a state</option>
                              <!-- States will populate based on the selected country -->
                            </select>
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="city" class="form-label">City</label>
                            {{-- <input
                              class="form-control"
                              type="text"
                              id="city"
                              name="city"
                              value=""
                              autofocus
                              required
                            /> --}}
                            <select id="cities" class="form-control chosen-select" name="city">
                              <option value="">Select a city</option>
                              <!-- Cities will populate based on the selected state -->
                            </select>
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="Pincode" class="form-label">Pincode</label>
                            <div class="form-control" style="border:none;padding:0;">
                              <input
                                class="form-control"
                                type="number"
                                id="Pincode"
                                name="pincode"
                                value=""
                                min="0"
                                autofocus
                                required
                              />
                              <span id="PincodeSpan"></span>
                            </div>
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">Property For</label>
                            <select id="propertyFor" class="select2 form-select" name="property_for" required>
                              <option value="">Select</option>
                              <option value="0">Rent</option>
                              <option value="1">PMS</option>
                              <option value="2">Both</option>
                            </select>
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="State" class="form-label">Phone </label>
                            <div class="form-control" style="border: none; padding:0px"><input
                                class="form-control"
                                type="tel"
                                id="Number"
                                name="Number"
                                value=""
                                pattern="^([0-9]){10,10}$"
                                autofocus
                                required
                              />
                                <span id="NumberSpan"></span>
                              </div>
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="State" class="form-label">Email</label>
                            <div class="form-control" style="border: none; padding:0px">
                              <input
                                class="form-control"
                                type="text"
                                id="emailInput"
                                name="email"
                                value=""
                                autofocus
                                required
                              />
                              <span id="emailSpan"></span>
                            </div>
                          </div> 
                          {{-- <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="State" class="form-label">Packages</label>
                            <select class="form-control"  id="package" name="packages" required>
                              @foreach ($packages as $itempac)
                                  <option value="{{ $itempac->id }}">{{ $itempac->packages_name }}</option>
                              @endforeach
                            </select>
                          </div>     --}}
                          <div class="mt-2 legendFormSubBTN ">
                            <input type="submit" class="btn btn-primary me-2" id="nextBtn" value="Next">
                          </div>
                      </div>
                    </div>
                    {{-- <div class="legendForm card-body demo-vertical-spacing demo-only-element" id="propUnit" style="display:none">
                      <legend><b style="font-size:0.75rem"><i class="fa-regular fa-building"></i>PROPERTY UNITS </b> </legend> 
                      <div class="row">
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="propertySize" class="form-label">UNIT NAME</label>
                            <input type="text" placeholder="" name="unitname"  class="form-control">
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="propertySize" class="form-label">BED ROOM</label>
                            <input type="number" placeholder="200" name="bedroom"    min="0" class="form-control">
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="propcats" class="form-label">BATH</label>
                            <input type="number" class="form-control" min="0"  name="BATH"  >
                    
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">KITCHEN</label>
                            <input type="number" class="form-control" min="0"  name="kitchen"  > 
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">GENERAL RENT</label>
                            <input type="number" placeholder="200" name="general" min="0"  class="form-control">
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">SECURITY DEPOSITE</label>
                            <input type="number" placeholder="200" name="securitydeposite" min="0"  class="form-control">
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">LATE FEES</label>
                            <input type="number" placeholder="200" name="latefees" min="0" class="form-control">
                          </div> 
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">ADULT</label>
                            <input type="number" placeholder="200" name="adult" min="0" class="form-control">
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">CHILD</label>
                            <input type="number" placeholder="200" name="child" min="0" class="form-control">
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">RENT TYPE</label>
                            <select name="rentype" id="rentype"   class="form-control">
                               <option value="0">Monthly</option>
                               <option value="1">Yearly</option>
                               <option value="2">Custom</option>
                            </select>
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6 customfield" style="display:none;">
                            <label for="language" class="form-label ">LEASE START DATE</label>
                            <input type="date"  name="leasestartdate"  class="form-control" multiple>
                          </div>  
                          <div class="mb-3  InputeFlexToChangeFields col-md-6 customfield" style="display:none;">
                            <label for="language" class="form-label ">LEASE END DATE</label>
                            <input type="date"  name="leaseenddate"  class="form-control" multiple>
                          </div>  
                          <div class="mb-3  InputeFlexToChangeFields col-md-6 customfield" style="display:none;">
                            <label for="language" class="form-label ">PAY DUE DATE</label>
                            <input type="date"  name="Payduedate"  class="form-control" multiple>
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">Images</label>
                            <input type="file" placeholder="200" name="propertyDocuments[]"  class="form-control" multiple>
                          </div>     
                      </div>
                    </div> --}}
                    <div class="legendForm card-body demo-vertical-spacing demo-only-element">
                      <legend><b style="font-size:0.75rem"><i class="fa-regular fa-building"></i>PROPERTY DETAILS </b> </legend> 
                      <div class="row">
                        {{-- <div class="mb-3  InputeFlexToChangeFields col-md-6">
                          <label for="propertySize" class="form-label">BuildUp Area</label>
                          <input type="number" placeholder="" name="builduparea" id=""  required class="form-control">
                        </div>
                        <div class="mb-3  InputeFlexToChangeFields col-md-6">
                          <label for="propertySize" class="form-label">CoverUp Area</label>
                          <input type="number" placeholder="" name="coveruparea" id=""  required class="form-control">
                        </div> --}}
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="propertySize" class="form-label">Sqr_meter</label>
                            <input type="number" placeholder="" name="sqr_meter" id="sqrmt" min="0" required class="form-control">
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="propertySize" class="form-label">Sqr_feet</label>
                            <input type="number" placeholder="" name="sqr_Feet" id="sqrft" min="0" readonly required class="form-control">
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="propcats" class="form-label">Property Room</label>
                            <input type="number" class="form-control"  name="rooms"  required>
                            {{-- <select  >
                              <option value="1">1</option>
                              <option value="2">2</option>
                              <option value="3">3</option>
                              <option value="4">4</option>
                            </select> --}}
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">Property Floor</label>
                            <input type="number" class="form-control"  name="Floor"  required> 
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">Start Date</label>
                            <div class="form-control" style="border:none;padding:0;">
                              <input type="date" placeholder="200" name="start_date" id="txtFrom" required class="form-control">
                               <span id="fromSpan"></span>   
                            </div>
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">End Date</label>
                            <div class="form-control" style="border:none;padding:0;">
                            <input type="date" placeholder="200" name="end_date" id="txtTo" required class="form-control">
                            <span id="toSpan"></span>   
                            </div>
                          </div> 
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">Construction</label>
                            <input type="date" placeholder="200" name="cons_date" required class="form-control">
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">Renovation</label>
                            <input type="date" placeholder="200" name="renova_date" required class="form-control">
                          </div>
                          <div class="mb-3  InputeFlexToChangeFields col-md-6">
                            <label for="language" class="form-label">Property Images</label>
                            <input type="file" placeholder="200" name="propertyImages[]" required class="form-control" multiple>
                          </div>   
                      </div>
                    </div>
                    <div class="legendForm card-body demo-vertical-spacing demo-only-element">
                      <legend><b style="font-size:0.75rem"><i class="fa-regular fa-building"></i>PROPERTY FACILITY </b> </legend> 
                      <div class="row">
                          
                          
                          
                          <div class="mb-3  InputeFlexToChangeFields col-md-12 hiddenCB">
                            <!-- <label for="language" class="form-label">Property Utility</label><br> -->
                            <div  class="scrl" style="overflow-y: scroll; width:100%;height:60px;" id="lBox2">
                              Please Select Property Type
                            </div>
                          </div>
                          {{-- <button class="btn btn-primary" style=" height:30px; width:30px; margin-left:10px; display:flex; justify-content:center;align-items:center;" data-bs-toggle="modal" data-bs-target="#modalCenterfac"><i style="font-size:17px" class="fa-solid fa-plus"></i></button> --}}
                          
                      </div>
                    </div>
                    <div class="legendForm card-body demo-vertical-spacing demo-only-element">
                      <legend><b style="font-size:0.75rem"><i class="fa-regular fa-building"></i>OutDoor Features</b> </legend> 
                      <div class="row">
                          
                     
                          
                          
                          <div class="mb-3  InputeFlexToChangeFields col-md-12 hiddenCB">
                            <!-- <label for="language" class="form-label">OutDoor Features</label><br> -->
                            <div  class="scrl" style="overflow-y: scroll; width:100%;height:60px;" id="lBox">
                              Please Select Property Type
                            </div>
                          </div>
                          {{-- <button class="btn btn-primary" style=" height:30px; width:30px; margin-left:10px; display:flex; justify-content:center;align-items:center;" data-bs-toggle="modal" data-bs-target="#modalCenteroutdoor"><i style="font-size:17px" class="fa-solid fa-plus"></i></button> --}}
                         
                      </div>
                    </div>
                    <div class="legendForm card-body demo-vertical-spacing demo-only-element">
                      <legend><b style="font-size:0.75rem"><i class="fa-regular fa-building"></i>inDoor Features</b> </legend> 
                      <div class="row">
                          
                          <div class="mb-3  InputeFlexToChangeFields col-md-12 hiddenCB">
                            <!-- <label for="language" class="form-label">inDoor Features</label><br> -->
                            <div  class="scrl" style="overflow-y: scroll; width:100%;height:60px;" id="lBox3">
                              Please Select Property Type 
                            </div>
                          </div>
                          {{-- <button class="btn btn-primary" style=" height:30px; width:30px; margin-left:10px; display:flex; justify-content:center;align-items:center;" data-bs-toggle="modal" data-bs-target="#modalCenterindoor"><i style="font-size:17px" class="fa-solid fa-plus"></i></button> --}}
                          
                        
                      </div>
                    </div>
                    <div class="legendForm card-body demo-vertical-spacing demo-only-element">
                      <legend><b style="font-size:0.75rem"><i class="fa-regular fa-building"></i>Near by</b> </legend> 
                      <div class="row">
                      <div class="col-md-4">
                            <div class="form-check d-flex checkboxcontaniner align-items-center mb-3">
                              <input class="form-check-input attch" type="checkbox" name="nearby[]" value="park" >
                              <label class="form-check-label mx-3" for="flexCheckDefault">
                                Park
                              </label>
                              <input type="text" style="max-width:200px"  class="form-control attchvalue" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-check d-flex checkboxcontaniner align-items-center mb-3">
                              <input class="form-check-input attch" type="checkbox" name="nearby[]" value="busStation" id="flexCheckDefault">
                              <label class="form-check-label mx-3" for="flexCheckDefault">
                                Bus Station
                              </label>
                              <input type="text" style="max-width:200px"  class="form-control attchvalue" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-check d-flex checkboxcontaniner align-items-center mb-3">
                              <input class="form-check-input attch" type="checkbox" name="nearby[]" value="metroStation" id="flexCheckDefault">
                              <label class="form-check-label mx-3" for="flexCheckDefault">
                                Metro Station
                              </label>
                              <input type="text" style="max-width:200px"  class="form-control attchvalue" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-check d-flex checkboxcontaniner align-items-center mb-3">
                              <input class="form-check-input attch" type="checkbox" name="nearby[]" value="mall" id="flexCheckDefault">
                              <label class="form-check-label mx-3" for="flexCheckDefault">
                                Mall
                              </label>
                              <input type="text" style="max-width:200px" class="form-control attchvalue" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-check d-flex checkboxcontaniner align-items-center mb-3">
                              <input class="form-check-input attch" type="checkbox" name="nearby[]" value="cafe" id="flexCheckDefault">
                              <label class="form-check-label mx-3" for="flexCheckDefault">
                                Cafe
                              </label>
                              <input type="text" style="max-width:200px"  class="form-control attchvalue" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-check d-flex checkboxcontaniner align-items-center mb-3">
                              <input class="form-check-input attch" type="checkbox" name="nearby[]" value="Market" id="flexCheckDefault">
                              <label class="form-check-label mx-3" for="flexCheckDefault">
                                Market
                              </label>
                              <input type="text" style="max-width:200px" class="form-control attchvalue" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-check d-flex checkboxcontaniner align-items-center mb-3">
                              <input class="form-check-input attch" type="checkbox" name="nearby[]" value="PoliceStation" id="flexCheckDefault">
                              <label class="form-check-label mx-3" for="flexCheckDefault">
                                Police station
                              </label>
                              <input type="text" style="max-width:200px" class="form-control attchvalue" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-check d-flex checkboxcontaniner align-items-center mb-3">
                              <input class="form-check-input attch" type="checkbox" name="nearby[]" value="Market" id="flexCheckDefault">
                              <label class="form-check-label mx-3" for="flexCheckDefault">
                                Market
                              </label>
                              <input type="text" style="max-width:200px"  class="form-control attchvalue" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-check d-flex checkboxcontaniner align-items-center mb-3">
                              <input class="form-check-input attch" type="checkbox" name="nearby[]" value="Hospital" id="flexCheckDefault">
                              <label class="form-check-label mx-3" for="flexCheckDefault">
                                Hospital
                              </label>
                              <input type="text" style="max-width:200px"  class="form-control attchvalue" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-check d-flex checkboxcontaniner align-items-center mb-3">
                              <input class="form-check-input attch" type="checkbox" name="nearby[]" value="Airport" id="flexCheckDefault">
                              <label class="form-check-label mx-3" for="flexCheckDefault">
                                Airport
                              </label>
                              <input type="text" style="max-width:200px"  class="form-control attchvalue" />
                            </div>
                          </div>
                      </div>
                    </div>
                    <div class="legendForm card-body demo-vertical-spacing demo-only-element">
                      <legend><b style="font-size:0.75rem"><i class="fa-regular fa-building"></i>Property Issues</b> </legend> 
                      <div class="row">
                          
                          <div class="mb-3  InputeFlexToChangeFields col-md-12 hiddenCB">
                            <!-- <label for="language" class="form-label">inDoor Features</label><br> -->
                            <input name="issues" class="form-control" id="" data-role="tagsinput" style="height:400px !important;">
                          </div>
                      </div>
                    </div>
                    <div class="mt-2 legendFormSubBTN ">
                      <input type="submit" class="btn btn-primary me-2" id="nextBtn" value="Next">
                    </div>
              </div>

              
            </div> 
           {{-- </div>
           </div> --}}
         <!-- Merged -->
       </form>
    </div>
    <!-- / Content -->

    <!-- Footer -->
    <footer class="content-footer footer bg-footer-theme">
      <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
          ©
          <script>
            document.write(new Date().getFullYear());
          </script>
          , made with ❤️ by
          <a href="#" target="_blank" class="footer-link fw-bolder">SkyLabs Solution Pvt. Ltd</a>
        </div>
        {{-- <div>
          <a href="https://themeselection.com/license/" class="footer-link me-4" target="_blank">License</a>
          <a href="https://themeselection.com/" target="_blank" class="footer-link me-4">More Themes</a>

          <a
            href="https://themeselection.com/demo/sneat-bootstrap-html-admin-template/documentation/"
            target="_blank"
            class="footer-link me-4"
            >Documentation</a
          >

          <a
            href="https://github.com/themeselection/sneat-html-admin-template-free/issues"
            target="_blank"
            class="footer-link me-4"
            >Support</a
          >
        </div> --}}
      </div>
    </footer>
    <!-- / Footer -->

    <div class="content-backdrop fade"></div>
  </div>
 <!-- category Modal -->
@if (Auth::user()->role_as==10) 
<!-- category Modal -->
  <div class="modal fade" id="modalCenter" tabindex="-1" aria-hidden="true">
    <form action="{{ route('masterCategory') }}" method="post" enctype="multipart/form-data">
      @csrf
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalCenterTitle">Add New Categories</h5>
          <button
            type="button"
            class="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
          ></button>
        </div>
        <div class="modal-body">
          <div class="row g-2">
            <div class="col mb-0">
              <label for="nameWithTitle" class="form-label">Category Name</label>
              <input
                type="text"
                {{-- id="propcategoryname" --}}
                class="form-control"
                placeholder="Category Name"
                name="categoryname"
                reuired
              />
            </div>
            <div class="col mb-0"  id="taggs">
              <label for="emailWithTitle" class="form-label">Category Tags</label>
              <input
                type="text"
                placeholder="Category Tags"
                class="form-control"
                name="tags"
                data-role="tagsinput"
              />
            </div>
          </div>
          <div class="row g-2">
            <div class="col mb-0" id="isfeatured">
              <label class="form-label" for="basic-default-password12">isFeatured</label>
              <div class="input-group">
                <select  class="form-control" name="isfeatured" required>
                    <option value="1" selected>No</option>
                    <option value="0">yes</option>
                </select>
              </div>
            </div>
            <div class="col mb-0">
              <label for="dobWithTitle" class="form-label">Category Image</label>
              <input
                type="file"
                {{-- id="categoryImage" --}}
                class="form-control"
                name="categoryImage"
              />
            </div>
            {{-- <input type="hidden" name="id" id="id"> --}}
          </div>
          {{-- <div class="row g-2 mt-2" id="existimage">
            
          </div> --}}
        </div>
        <div class="modal-footer">
          {{-- <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
            Close
          </button> --}}
          <input type="submit" class="btn btn-primary" value="Save changes">
        </form>
        </div>
      </div>
    </div>
  </div>
{{-- category modal end here --}}
<!-- owner Modal -->
<div class="modal fade" id="largeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel3">Add Owner</h5>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
        ></button>
      </div>
      <div class="modal-body">
        <form id="formAccountSettings" action="{{ route('addUser') }}" method="post" enctype="multipart/form-data">
          @csrf
          <div class="card mb-4">
              <h5 class="card-header">Owner Details</h5>
              <!-- Account -->
              <div class="card-body">
                <div class="d-flex align-items-start align-items-sm-center gap-4">
                  <img
                    id="imagePView"
                    src="../assets/img/avatars/1.png"
                    alt="user-avatar"
                    class="d-block rounded"
                    height="100"
                    width="100"
                   
                  />
                  <div class="button-wrapper">
                    <label for="upload" class="btn btn-primary me-2 mb-4" tabindex="0">
                      <span class="d-none d-sm-block">Upload photo</span>
                      <i class="bx bx-upload d-block d-sm-none"></i>
                      <input
                        type="file"
                        id="upload"
                        class="account-file-input"
                        hidden
                        accept="image/png, image/jpeg"
                        name = "profileimage"
                      />
                    </label>
                    {{-- <button type="button" class="btn btn-outline-secondary account-image-reset mb-4">
                      <i class="bx bx-reset d-block d-sm-none"></i>
                      <span class="d-none d-sm-block">Reset</span>
                    </button> 
                    <p class="text-muted mb-0">Allowed JPG, GIF or PNG.
                       Max size of 800K
                    </p> --}}
                  </div>
                </div>
              </div>
              <hr class="my-0" />
              <div class="card-body">
               
                  <div class="row">
                    <div class="mb-3 col-md-6">
                      <label for="firstName" class="form-label">Owner Name</label>
                      <input
                        class="form-control"
                        type="text"
                        id="firstName"
                        name="fullname"
                        value="John"
                        autofocus
                        required
                      />
                    </div>
                    <div class="mb-3 col-md-6">
                      <label for="email" class="form-label">E-mail</label>
                      <input
                        class="form-control"
                        type="text"
                        id="email"
                        name="email"
                        value="john.doe@example.com"
                        placeholder="john.doe@example.com"
                        required
                      />
                    </div>
                    {{-- <div class="mb-3 col-md-6">
                      <label for="organization" class="form-label">Organization</label>
                      <input
                        type="text"
                        class="form-control"
                        id="organization"
                        name="organization"
                        value="ThemeSelection"
                      />
                    </div> --}}
                    <div class="mb-3 col-md-6">
                      <label class="form-label" for="phoneNumber">Phone Number</label>
                      <div class="input-group input-group-merge">
                        {{-- <span class="input-group-text">US (+1)</span> --}}
                        <input
                          type="tel"
                          id="phoneNumber"
                          name="phoneNumber"
                          class="form-control"
                          placeholder="202 555 0111"
                          required
                        />
                        <input type="hidden" name="role" value="5">
                      </div>
                    </div>
                    <div class="mb-3 col-md-6">
                      <label for="address" class="form-label">Address</label>
                      <input type="text" class="form-control" id="address" name="address" placeholder="Address" required />
                    </div>
                    <div class="mb-3 col-md-6">
                      <label class="form-label" for="country">Country</label>
                      {{-- <select  class="select2 form-select" name="country" onchange="print_state('state',this.selectedIndex)" id="country" required>
                      
                      </select> --}}
                      <input type="text"  class="form-control" name="country" id="country"
                        placeholder="country">
                    </div>
                    <div class="mb-3 col-md-6">
                      <label for="state" class="form-label">State</label>
                      {{-- <select  class="select2 form-select" id="state" name="state" required>
                  
                      </select> --}}
                      <input type="text" class="form-control" name="state" id="state"
                       placeholder="state">
                    </div>
                    <div class="mb-3 col-md-6">
                      <label for="language" class="form-label">City</label>
                      <input type="text" placeholder="City Here..." name="city"  required class="form-control">
                    </div>
                    <div class="mb-3 col-md-6">
                      <label for="zipCode" class="form-label">Zip Code</label>
                      <input
                        type="text"
                        class="form-control"
                        id="zipCode"
                        name="zipCode"
                        placeholder="231465"
                        maxlength="6"
                        required
                      />
                    </div>
                    <div class="mb-3 col-md-6">
                      <label for="" class="form-label">Password</label>
                      <input
                        type="password"
                        class="form-control"
                        {{-- id="zipCode" --}}
                        name="password"
                        placeholder="******"
                        maxlength="6"
                        required
                      />
                    </div>
                    {{-- <div class="mb-3 col-md-6">
                      <label for="language" class="form-label">Give Permission</label>
                      <select id="language" class="select2 form-select" name="role" required>
                        <option value="">Select Permission</option>
                        <option value="0">Admin</option>
                        <option value="1">Customber/tenant</option>
                        <option value="2">Site Engineer</option>
                        <option value="3">Vendor</option>
                        <option value="4">Support/Help Desk</option>
                      </select>
                    </div>
                    <div class="mb-3 col-md-6">
                      <label for="language" class="form-label">Passoword</label>
                      <input type="password" placeholder="Password Here..." name="password" required class="form-control">
                    </div> --}}
                    
                  </div>
                  {{-- <div class="mt-2">
                    <button type="submit" class="btn btn-primary me-2">Save changes</button>
                    <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                  </div> --}}
              </div>
              <!-- /Account -->
          </div>
      </div>
      <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
              Cancel
          </button>
          <button type="submit" class="btn btn-primary">Add Owner</button>
      </div>
  </form>
    </div>
  </div>
</div>

{{-- owner modal end here --}}
@endif
{{-- property fasility --}}
{{-- Modal  --}}
<!-- Vertically Centered Modal -->
<div class="col-lg-4 col-md-6">
  <div class="mt-3">
    <!-- Modal -->
    <div class="modal fade" id="modalCenterfac" tabindex="-1" aria-hidden="true">
      @if (Auth::user()->role_as == 10)
      <form action="{{ route('addFeatureList') }}" method="post" enctype="multipart/form-data">
        @csrf
      @elseif (Auth::user()->role_as == 5)   
      <form action="{{ route('owneraddFeatureList') }}" method="post" enctype="multipart/form-data">
        @csrf 
      @endif
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalCenterTitle">Add new facility</h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div class="modal-body">
            <div class="row g-2">
              <div class="col mb-0">
                <label for="nameWithTitle" class="form-label">Feature Name</label>
                <input
                  type="text"
                  {{-- id="featurename" --}}
                  class="form-control"
                  placeholder="Feature Name"
                  name="featurename"
                  reuired
                />
              </div>
              <div class="col mb-0">
                <label class="form-label" for="basic-default-password12">Select Category</label>
                  <div class="input-group">
                    <select  class="form-control" name="category" id="featureCategory" required>
                      @foreach ($categoriesDetails as $categoryItem)
                         <option value="{{ $categoryItem->category_id }}">{{ $categoryItem->category_name }}</option>
                      @endforeach
                    </select>
                  </div>
              </div>
            </div>
          </div>
          {{-- <input type="hidden" name="id" id="id"> --}}
          <div class="modal-footer">
            {{-- <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
              Close
            </button> --}}
            <input type="submit" class="btn btn-primary" value="Save changes">

          </div>
        </div>
      </div>
    </div>
  </div>
   </form>
</div> 
{{-- property fasicility end here --}}
  <!-- indoor Modal -->
  <div class="modal fade" id="modalCenterindoor" tabindex="-1" aria-hidden="true">
    @if (Auth::user()->role_as == 10)
    <form action="{{ route('addPropertyIndoor') }}" method="post" enctype="multipart/form-data">
      @csrf
    @elseif(Auth::user()->role_as==5)
    <form action="{{ route('owneraddPropertyIndoor') }}" method="post" enctype="multipart/form-data">
      @csrf
    @endif
   
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalCenterTitle">Make Changes in indoor List</h5>
          <button
            type="button"
            class="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
          ></button>
        </div>
        <div class="modal-body">
          <div class="row g-2">
            <div class="col mb-0">
              <label for="nameWithTitle" class="form-label">indoor Name</label>
              <input
                type="text"
                {{-- id="indoorName" --}}
                class="form-control"
                placeholder="indoor Name"
                name="indoorname"
                reuired
              />
            </div>
            <div class="col mb-0">
              <label class="form-label" for="basic-default-password12">Select Category</label>
                <div class="input-group">
                  <select  class="form-control" name="category" id="indoorCategory" required>
                    @foreach ($categoriesDetails as $categoryItem)
                       <option value="{{ $categoryItem->category_id }}">{{ $categoryItem->category_name }}</option>
                    @endforeach
                  </select>
                </div>
            </div>
          </div>
        </div>
        {{-- <input type="hidden" name="id" id="id"> --}}
        <div class="modal-footer">
          {{-- <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
            Close
          </button> --}}
          <input type="submit" class="btn btn-primary" value="Save changes">

        </div>
      </div>
    </div>
  </div>
</div>
</form>
</div> 
{{-- indoor features end here --}}
    <!-- Modal -->
<div class="modal fade" id="modalCenteroutdoor" tabindex="-1" aria-hidden="true">
      @if (Auth::user()->role_as == 10)
      <form action="{{ route('addPropertyOutdoor') }}" method="post" enctype="multipart/form-data">
        @csrf
      @elseif (Auth::user()->role_as == 5)
      <form action="{{ route('owneraddPropertyOutdoor') }}" method="post" enctype="multipart/form-data">
        @csrf
      @endif  
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalCenterTitle">Outdoor features</h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div class="modal-body">
            <div class="row g-2">
              <div class="col mb-0">
                <label for="nameWithTitle" class="form-label">Outdoor Name</label>
                <input
                  type="text"
                  {{-- id="outdoorName" --}}
                  class="form-control"
                  placeholder="Outdoor Name"
                  name="outdoorname"
                  reuired
                />
              </div>
              <div class="col mb-0">
                <label class="form-label" for="basic-default-password12">Select Category</label>
                  <div class="input-group">
                    <select  class="form-control" name="category" id="outdoorCategory" required>
                      @foreach ($categoriesDetails as $categoryItem)
                         <option value="{{ $categoryItem->category_id }}">{{ $categoryItem->category_name }}</option>
                      @endforeach
                    </select>
                  </div>
              </div>
            </div>
          </div>
          {{-- <input type="hidden" name="id" id="id"> --}}
          <div class="modal-footer">
            {{-- <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
              Close
            </button> --}}
            <input type="submit" class="btn btn-primary" value="Save changes">

          </div>
        </div>
      </div>
        </div>
        </div>
      </form>
</div>  
{{-- outdoor features add here --}}
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $(".propcat").change(function (event) {
            // event.preventDefault(); 

            var propcats = document.getElementById('propcats').value
            oowner = document.getElementById('oowner')
            if(oowner.value == 5)
            {
              rute = "{{ url('owner/featuresbycategories')}}/"+propcats
              rutesec ="{{ url('owner/proputlfeatures')}}/"+propcats
              rutethird = "{{ url('owner/indoorcatfeatures')}}/"+propcats
            }else if(oowner.value == 10)
            {

              rute = "{{ url('superadmin/featuresbycategories')}}/"+propcats
              rutesec ="{{ url('superadmin/proputlfeatures')}}/"+propcats
              rutethird = "{{ url('superadmin/indoorcatfeatures')}}/"+propcats
            }
            $.ajax({
                type: "GET",
                url:rute,
                processData: false,
                contentType: false,
                success: function (response) {
                    $("#lBox").html(response); 
                      console.log(response)
                },
            });
            $.ajax({
                type: "GET",
                url:rutesec,
                processData: false,
                contentType: false,
                success: function (response) {
                    $("#lBox2").html(response); 
                      console.log(response)
                },
            });
            $.ajax({
                type: "GET",
                url:rutethird,
                processData: false,
                contentType: false,
                success: function (response) {
                    $("#lBox3").html(response); 
                      console.log(response)
                },
            });
            
        });
    });
</script>
<style>
  .InputeFlexToChangeFields label{ min-width:117px}
  .InputeFlexToChangeFields{display: flex;
    align-items: center;}
  .legendForm legend b{position: absolute;
    background: #fff;
    left: 20px;
    top: -13px;
    padding: 2px 13px;
    border-radius: 3px;
    box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    /* font-size: 12px !important; */
    font-weight: 400;
}
.legendForm{ box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px; margin-bottom:0px; width:88%; margin:0px auto; margin-bottom:50px; position: relative}
.legendForm .card-body.demo-vertical-spacing.demo-only-element{box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    width: 100%; padding-top:40px;
    margin: 0px auto;}
    .fa-building{ font-size:16px; margin-right:6px}
    .checkboxcontaniner label{ min-width:110px}
    .form-check-input[type=checkbox] {
    border-radius: 10px;
    height: 17px;
    width: 30px;
}
.legendFormSubBTN{ width:88%; margin:0px auto;}
</style>
{{-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css"> --}}
<script>
  function checkFields() {
    emaill = document.getElementById('emailInput').value;
    numbere = document.getElementById('Number').value;
    pincodee = document.getElementById('Pincode').value;
    emailValid = validateEmail(emaill);
    numberValid = validateMobileNumber(numbere);
    pincodeValid = validateIndianPostalCode(pincodee);
    allValid = emailValid && numberValid && pincodeValid;
    if (allValid) {
      nextBtn.disabled = false;
    } else {
      nextBtn.disabled = true;
    }
  }
  nextBtn = document.getElementById('nextBtn');
  // email validation
  emailSpan = document.getElementById('emailSpan')
  emailFields = document.getElementById('emailInput')
  function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }
  emailFields.addEventListener('input',function(e){
    emailInput = document.getElementById('emailInput').value;
    if (validateEmail(emailInput)) {
      emailSpan.style.color = 'green'
      emailSpan.innerText = "Valid Email"
      nextBtn.disabled = false
    } else {
      emailSpan.style.color = 'red'
      emailSpan.innerText = "Invalid email"
      nextBtn.disabled = true
    }
    checkFields()
  })
  //Mobile Number Validation
  Numbers = document.getElementById('Number');
  NumberSpan = document.getElementById('NumberSpan');
  
  function validateMobileNumber(numbers) {
    const re = /^[0-9]{10}$/; // Assumes a 10-digit number without any formatting characters
    return re.test(numbers);
  }
  Numbers.addEventListener('input',function(e){
     const phoneNumber = document.getElementById('Number').value;
     if (validateMobileNumber(phoneNumber)) {
       NumberSpan.innerText = "Valid phone number"
       NumberSpan.style.color = "green";
       nextBtn.disabled = false
      // console.log('Valid phone number');
     } else {
       NumberSpan.innerText = "Invalid phone number"
       NumberSpan.style.color = "red"
       nextBtn.disabled = true
      // console.log('Invalid phone number');
     }
     checkFields()
  })
 //pincode Validation
 Pincode = document.getElementById('Pincode');
 PincodeSpan = document.getElementById('PincodeSpan');
 function validateIndianPostalCode(code) {
  const indianPinRegex = /^[1-9][0-9]{5}$/;
    return indianPinRegex.test(code);
  }
 Pincode.addEventListener('input',function(e){
   const indianPostalCode = document.getElementById('Pincode').value;
   if (validateIndianPostalCode(indianPostalCode)) {
     PincodeSpan.style.color = "green"
     PincodeSpan.innerText = "Valid Indian postal code"
     nextBtn.disabled = false
   } else {
     PincodeSpan.style.color = "red"
     PincodeSpan.innerText = "Invalid Indian postal code"
     nextBtn.disabled = true
   }
   checkFields()
 })
 //sqr feet calculation
 sqrmt = document.getElementById('sqrmt')
 sqrft = document.getElementById('sqrft')
 sqrmt.addEventListener('input',function(e){
   feet = sqrmt.value * Math.ceil(10.7639)
   sqrft.value = feet
 })
//  if(sqrft)
//  {
//   console.log(sqrft.value)
//    if(sqrft.value == 0)
//    {
//       nextBtn.disabled = true
//    }else
//    {
//       nextBtn.disabled = false
//    }
//  }
 //start date to end  date
 function validateDates(startDate, endDate) {
  // Convert the date strings to Date objects
  const start = new Date(startDate);
  const end = new Date(endDate);

  // Check if the start date is greater than the end date
  if (start > end) {
    return false; 
  }else
  {
    return true; 
  }

 }

 // Example usage:
  fromSpan = document.getElementById('fromSpan');
  toSpan = document.getElementById('toSpan');
  document.getElementById('txtFrom').addEventListener('input',function(e){
    const startDate = document.getElementById('txtFrom').value; // Replace with your start date
    const endDate = document.getElementById('txtTo').value; // Replace with your end date
    const isValid = validateDates(startDate,endDate);
    if (isValid) {
      fromSpan.innerText = 'Valid date range!'
      fromSpan.style.color = 'green'
      toSpan.innerText = 'Valid date range!'
      toSpan.style.color = 'green'
      nextBtn.disabled = false
    } else {
      fromSpan.innerText = 'Invalid date range!'
      fromSpan.style.color = 'red'
      toSpan.innerText = 'Invalid date range!'
      toSpan.style.color = 'red'
      nextBtn.disabled = true
    }
  })
  document.getElementById('txtTo').addEventListener('input',function(e){
    const startDate = document.getElementById('txtFrom').value; // Replace with your start date
    const endDate = document.getElementById('txtTo').value; // Replace with your end date
    const isValid = validateDates(startDate, endDate);
    if (isValid) {
      fromSpan.innerText = 'Valid date range!'
      fromSpan.style.color = 'green'
      toSpan.innerText = 'Valid date range!'
      toSpan.style.color = 'green'
      nextBtn.disabled = false
    } else {
      fromSpan.innerText = 'Invalid date range!'
      fromSpan.style.color = 'red'
      toSpan.innerText = 'Invalid date range!'
      toSpan.style.color = 'red'
      nextBtn.disabled = true
    }
    })
  // console.log(toDate)
</script>
<script type="text/javascript">
  document.addEventListener('DOMContentLoaded', function() {
    // Dummy data for demonstration
    const countries = [
      // { code: 'AF', name: 'Afghanistan' },
      // { code: 'AX', name: 'Åland Islands' },
      // { code: 'AL', name: 'Albania' },
      // { code: 'DZ', name: 'Algeria' },
      // { code: 'AS', name: 'American Samoa' },
      // { code: 'AD', name: 'Andorra' },
      // { code: 'AO', name: 'Angola' },
      // { code: 'AI', name: 'Anguilla' },
      // { code: 'AQ', name: 'Antarctica' },
      // { code: 'AG', name: 'Antigua and Barbuda' },
      // { code: 'AR', name: 'Argentina' },
      // { code: 'AM', name: 'Armenia' },
      // { code: 'AW', name: 'Aruba' },
      // { code: 'AU', name: 'Australia' },
      // { code: 'AT', name: 'Austria' },
      // { code: 'AZ', name: 'Azerbaijan' },
      // { code: 'BS', name: 'Bahamas' },
      // { code: 'BH', name: 'Bahrain' },
      // { code: 'BD', name: 'Bangladesh' },
      // { code: 'BB', name: 'Barbados' },
      // { code: 'BY', name: 'Belarus' },
      // { code: 'BE', name: 'Belgium' },
      // { code: 'BZ', name: 'Belize' },
      // { code: 'BJ', name: 'Benin' },
      // { code: 'BM', name: 'Bermuda' },
      // { code: 'BT', name: 'Bhutan' },
      // { code: 'BO', name: 'Bolivia (Plurinational State of)' },
      // { code: 'BQ', name: 'Bonaire, Sint Eustatius and Saba' },
      // { code: 'BA', name: 'Bosnia and Herzegovina' },
      // { code: 'BW', name: 'Botswana' },
      // { code: 'BV', name: 'Bouvet Island' },
      // { code: 'BR', name: 'Brazil' },
      // { code: 'IO', name: 'British Indian Ocean Territory' },
      // { code: 'BN', name: 'Brunei Darussalam' },
      // { code: 'BG', name: 'Bulgaria' },
      // { code: 'BF', name: 'Burkina Faso' },
      // { code: 'BI', name: 'Burundi' },
      // { code: 'CV', name: 'Cabo Verde' },
      // { code: 'KH', name: 'Cambodia' },
      // { code: 'CM', name: 'Cameroon' },
      // { code: 'CA', name: 'Canada' },
      // { code: 'KY', name: 'Cayman Islands' },
      // { code: 'CF', name: 'Central African Republic' },
      // { code: 'TD', name: 'Chad' },
      // { code: 'CL', name: 'Chile' },
      // { code: 'CN', name: 'China' },
      // { code: 'CX', name: 'Christmas Island' },
      // { code: 'CC', name: 'Cocos (Keeling) Islands' },
      // { code: 'CO', name: 'Colombia' },
      // { code: 'KM', name: 'Comoros' },
      // { code: 'CG', name: 'Congo' },
      // { code: 'CD', name: 'Congo (Democratic Republic of the)' },
      // { code: 'CK', name: 'Cook Islands' },
      // { code: 'CR', name: 'Costa Rica' },
      // { code: 'HR', name: 'Croatia' },
      // { code: 'CU', name: 'Cuba' },
      // { code: 'CW', name: 'Curaçao' },
      // { code: 'CY', name: 'Cyprus' },
      // { code: 'CZ', name: 'Czech Republic' },
      // { code: 'DK', name: 'Denmark' },
      // { code: 'DJ', name: 'Djibouti' },
      // { code: 'DM', name: 'Dominica' },
      // { code: 'DO', name: 'Dominican Republic' },
      // { code: 'EC', name: 'Ecuador' },
      // { code: 'EG', name: 'Egypt' },
      // { code: 'SV', name: 'El Salvador' },
      // { code: 'GQ', name: 'Equatorial Guinea' },
      // { code: 'ER', name: 'Eritrea' },
      // { code: 'EE', name: 'Estonia' },
      // { code: 'ET', name: 'Ethiopia' },
      // { code: 'FK', name: 'Falkland Islands (Malvinas)' },
      // { code: 'FO', name: 'Faroe Islands' },
      // { code: 'FJ', name: 'Fiji' },
      // { code: 'FI', name: 'Finland' },
      // { code: 'FR', name: 'France' },
      // { code: 'GF', name: 'French Guiana' },
      // { code: 'PF', name: 'French Polynesia' },
      // { code: 'TF', name: 'French Southern Territories' },
      // { code: 'GA', name: 'Gabon' },
      // { code: 'GM', name: 'Gambia' },
      // { code: 'GE', name: 'Georgia' },
      // { code: 'DE', name: 'Germany' },
      // { code: 'GH', name: 'Ghana' },
      // { code: 'GI', name: 'Gibraltar' },
      // { code: 'GR', name: 'Greece' },
      // { code: 'GL', name: 'Greenland' },
      // { code: 'GD', name: 'Grenada' },
      // { code: 'GP', name: 'Guadeloupe' },
      // { code: 'GU', name: 'Guam' },
      // { code: 'GT', name: 'Guatemala' },
      // { code: 'GG', name: 'Guernsey' },
      // { code: 'GN', name: 'Guinea' },
      // { code: 'GW', name: 'Guinea-Bissau' },
      // { code: 'GY', name: 'Guyana' },
      // { code: 'HT', name: 'Haiti' },
      // { code: 'HM', name: 'Heard Island and McDonald Islands' },
      // { code: 'VA', name: 'Holy See' },
      // { code: 'HN', name: 'Honduras' },
      // { code: 'HK', name: 'Hong Kong' },
      // { code: 'HU', name: 'Hungary' },
      // { code: 'IS', name: 'Iceland' },
      { code: 'RU', name: 'Russia' },
      { code: 'IN', name: 'India' },
    ];

    const states = [
      { code: 'AL', name: 'Alabama', country: 'US' },
      { code: 'AK', name: 'Alaska', country: 'US' },
      { code: 'AZ', name: 'Arizona', country: 'US' },
      { code: 'AR', name: 'Arkansas', country: 'US' },
      { code: 'CA', name: 'California', country: 'US' },
      { code: 'CO', name: 'Colorado', country: 'US' },
      { code: 'CT', name: 'Connecticut', country: 'US' },
      { code: 'DE', name: 'Delaware', country: 'US' },
      { code: 'FL', name: 'Florida', country: 'US' },
      { code: 'GA', name: 'Georgia', country: 'US' },
      { code: 'HI', name: 'Hawaii', country: 'US' },
      { code: 'ID', name: 'Idaho', country: 'US' },
      { code: 'IL', name: 'Illinois', country: 'US' },
      { code: 'IN', name: 'Indiana', country: 'US' },
      { code: 'IA', name: 'Iowa', country: 'US' },
      { code: 'KS', name: 'Kansas', country: 'US' },
      { code: 'KY', name: 'Kentucky', country: 'US' },
      { code: 'LA', name: 'Louisiana', country: 'US' },
      { code: 'ME', name: 'Maine', country: 'US' },
      { code: 'MD', name: 'Maryland', country: 'US' },
      { code: 'MA', name: 'Massachusetts', country: 'US' },
      { code: 'MI', name: 'Michigan', country: 'US' },
      { code: 'MN', name: 'Minnesota', country: 'US' },
      { code: 'MS', name: 'Mississippi', country: 'US' },
      { code: 'MO', name: 'Missouri', country: 'US' },
      { code: 'MT', name: 'Montana', country: 'US' },
      { code: 'NE', name: 'Nebraska', country: 'US' },
      { code: 'NV', name: 'Nevada', country: 'US' },
      { code: 'NH', name: 'New Hampshire', country: 'US' },
      { code: 'NJ', name: 'New Jersey', country: 'US' },
      { code: 'NM', name: 'New Mexico', country: 'US' },
      { code: 'NY', name: 'New York', country: 'US' },
      { code: 'NC', name: 'North Carolina', country: 'US' },
      { code: 'ND', name: 'North Dakota', country: 'US' },
      { code: 'OH', name: 'Ohio', country: 'US' },
      { code: 'OK', name: 'Oklahoma', country: 'US' },
      { code: 'OR', name: 'Oregon', country: 'US' },
      { code: 'PA', name: 'Pennsylvania', country: 'US' },
      { code: 'RI', name: 'Rhode Island', country: 'US' },
      { code: 'SC', name: 'South Carolina', country: 'US' },
      { code: 'SD', name: 'South Dakota', country: 'US' },
      { code: 'TN', name: 'Tennessee', country: 'US' },
      { code: 'TX', name: 'Texas', country: 'US' },
      { code: 'UT', name: 'Utah', country: 'US' },
      { code: 'VT', name: 'Vermont', country: 'US' },
      { code: 'VA', name: 'Virginia', country: 'US' },
      { code: 'WA', name: 'Washington', country: 'US' },
      { code: 'WV', name: 'West Virginia', country: 'US' },
      { code: 'WI', name: 'Wisconsin', country: 'US' },
      { code: 'WY', name: 'Wyoming', country: 'US' },
      { code: 'AN', name: 'Andaman and Nicobar Islands', country: 'IN' },
      { code: 'AP', name: 'Andhra Pradesh', country: 'IN' },
      { code: 'AR', name: 'Arunachal Pradesh', country: 'IN' },
      { code: 'AS', name: 'Assam', country: 'IN' },
      { code: 'BR', name: 'Bihar', country: 'IN' },
      { code: 'CH', name: 'Chandigarh', country: 'IN' },
      { code: 'CT', name: 'Chhattisgarh', country: 'IN' },
      { code: 'DN', name: 'Dadra and Nagar Haveli and Daman and Diu', country: 'IN' },
      { code: 'DL', name: 'Delhi', country: 'IN' },
      { code: 'GA', name: 'Goa', country: 'IN' },
      { code: 'GJ', name: 'Gujarat', country: 'IN' },
      { code: 'HR', name: 'Haryana', country: 'IN' },
      { code: 'HP', name: 'Himachal Pradesh', country: 'IN' },
      { code: 'JK', name: 'Jammu and Kashmir', country: 'IN' },
      { code: 'JH', name: 'Jharkhand', country: 'IN' },
      { code: 'KA', name: 'Karnataka', country: 'IN' },
      { code: 'KL', name: 'Kerala', country: 'IN' },
      { code: 'LD', name: 'Ladakh', country: 'IN' },
      { code: 'LA', name: 'Lakshadweep', country: 'IN' },
      { code: 'MP', name: 'Madhya Pradesh', country: 'IN' },
      { code: 'MH', name: 'Maharashtra', country: 'IN' },
      { code: 'MN', name: 'Manipur', country: 'IN' },
      { code: 'ML', name: 'Meghalaya', country: 'IN' },
      { code: 'MZ', name: 'Mizoram', country: 'IN' },
      { code: 'NL', name: 'Nagaland', country: 'IN' },
      { code: 'OR', name: 'Odisha', country: 'IN' },
      { code: 'PY', name: 'Puducherry', country: 'IN' },
      { code: 'PB', name: 'Punjab', country: 'IN' },
      { code: 'RJ', name: 'Rajasthan', country: 'IN' },
      { code: 'SK', name: 'Sikkim', country: 'IN' },
      { code: 'TN', name: 'Tamil Nadu', country: 'IN' },
      { code: 'TS', name: 'Telangana', country: 'IN' },
      { code: 'TR', name: 'Tripura', country: 'IN' },
      { code: 'UP', name: 'Uttar Pradesh', country: 'IN' },
      { code: 'UK', name: 'Uttarakhand', country: 'IN' },
      { code: 'WB', name: 'West Bengal', country: 'IN' },
      { code: 'AN', name: 'Andaman and Nicobar Islands', country: 'IN' },
      { code: 'AP', name: 'Andhra Pradesh', country: 'IN' },
      { code: 'AR', name: 'Arunachal Pradesh', country: 'IN' },
      { code: 'AS', name: 'Assam', country: 'IN' },
      { code: 'BR', name: 'Bihar', country: 'IN' },
      { code: 'CH', name: 'Chandigarh', country: 'IN' },
      { code: 'CT', name: 'Chhattisgarh', country: 'IN' },
      { code: 'DN', name: 'Dadra and Nagar Haveli and Daman and Diu', country: 'IN' },
      { code: 'DL', name: 'Delhi', country: 'IN' },
      { code: 'GA', name: 'Goa', country: 'IN' },
      { code: 'GJ', name: 'Gujarat', country: 'IN' },
      { code: 'HR', name: 'Haryana', country: 'IN' },
      { code: 'HP', name: 'Himachal Pradesh', country: 'IN' },
      { code: 'JK', name: 'Jammu and Kashmir', country: 'IN' },
      { code: 'JH', name: 'Jharkhand', country: 'IN' },
      { code: 'KA', name: 'Karnataka', country: 'IN' },
      { code: 'KL', name: 'Kerala', country: 'IN' },
      { code: 'LD', name: 'Ladakh', country: 'IN' },
      { code: 'LA', name: 'Lakshadweep', country: 'IN' },
      { code: 'MP', name: 'Madhya Pradesh', country: 'IN' },
      { code: 'MH', name: 'Maharashtra', country: 'IN' },
      { code: 'MN', name: 'Manipur', country: 'IN' },
      { code: 'ML', name: 'Meghalaya', country: 'IN' },
      { code: 'MZ', name: 'Mizoram', country: 'IN' },
      { code: 'NL', name: 'Nagaland', country: 'IN' },
      { code: 'OR', name: 'Odisha', country: 'IN' },
      { code: 'PY', name: 'Puducherry', country: 'IN' },
      { code: 'PB', name: 'Punjab', country: 'IN' },
      { code: 'RJ', name: 'Rajasthan', country: 'IN' },
      { code: 'SK', name: 'Sikkim', country: 'IN' },
      { code: 'TN', name: 'Tamil Nadu', country: 'IN' },
      { code: 'TS', name: 'Telangana', country: 'IN' },
      { code: 'TR', name: 'Tripura', country: 'IN' },
      { code: 'UP', name: 'Uttar Pradesh', country: 'IN' },
      { code: 'UK', name: 'Uttarakhand', country: 'IN' },
      { code: 'WB', name: 'West Bengal', country: 'IN' },
      //for russia
      { code: 'MOW', name: 'Moscow', country: 'RU' },
      { code: 'SPE', name: 'Saint Petersburg', country: 'RU' },
      { code: 'AD', name: 'Adygea Republic', country: 'RU' },
      { code: 'AL', name: 'Altai Republic', country: 'RU' },
      { code: 'ALT', name: 'Altai Krai', country: 'RU' },
      { code: 'AMU', name: 'Amur Oblast', country: 'RU' },
      { code: 'ARK', name: 'Arkhangelsk Oblast', country: 'RU' },
      { code: 'AST', name: 'Astrakhan Oblast', country: 'RU' },
      { code: 'BA', name: 'Bashkortostan Republic', country: 'RU' },
      { code: 'BEL', name: 'Belgorod Oblast', country: 'RU' },
      { code: 'BRY', name: 'Bryansk Oblast', country: 'RU' },
      { code: 'BU', name: 'Buryatia Republic', country: 'RU' },
      { code: 'CE', name: 'Chechnya Republic', country: 'RU' },
      { code: 'CHE', name: 'Chelyabinsk Oblast', country: 'RU' },
      { code: 'CHU', name: 'Chukotka Autonomous Okrug', country: 'RU' },
      { code: 'CU', name: 'Chuvash Republic', country: 'RU' },
      { code: 'DA', name: 'Dagestan Republic', country: 'RU' },
      { code: 'IN', name: 'Ingushetia Republic', country: 'RU' },
      { code: 'IRK', name: 'Irkutsk Oblast', country: 'RU' },
      { code: 'IVA', name: 'Ivanovo Oblast', country: 'RU' },
      { code: 'KAM', name: 'Kamchatka Krai', country: 'RU' },
      { code: 'KB', name: 'Kabardino-Balkar Republic', country: 'RU' },
      { code: 'KC', name: 'Karachay-Cherkess Republic', country: 'RU' },
      { code: 'KDA', name: 'Krasnodar Krai', country: 'RU' },
      { code: 'KYA', name: 'Krasnoyarsk Krai', country: 'RU' },
      { code: 'KGN', name: 'Kurgan Oblast', country: 'RU' },
      { code: 'KRS', name: 'Kursk Oblast', country: 'RU' },
      { code: 'LEN', name: 'Leningrad Oblast', country: 'RU' },
      { code: 'LIP', name: 'Lipetsk Oblast', country: 'RU' },
      { code: 'MAG', name: 'Magadan Oblast', country: 'RU' },
      { code: 'ME', name: 'Mari El Republic', country: 'RU' },
      { code: 'MO', name: 'Mordovia Republic', country: 'RU' },
      { code: 'MOS', name: 'Moscow Oblast', country: 'RU' },
      { code: 'MUR', name: 'Murmansk Oblast', country: 'RU' },
      { code: 'NEN', name: 'Nenets Autonomous Okrug', country: 'RU' },
      { code: 'NIZ', name: 'Nizhny Novgorod Oblast', country: 'RU' },
      { code: 'NGR', name: 'Novgorod Oblast', country: 'RU' },
      { code: 'NVS', name: 'Novosibirsk Oblast', country: 'RU' },
      { code: 'OMS', name: 'Omsk Oblast', country: 'RU' },
      { code: 'ORE', name: 'Orenburg Oblast', country: 'RU' },
      { code: 'ORL', name: 'Oryol Oblast', country: 'RU' },
      { code: 'PNZ', name: 'Penza Oblast', country: 'RU' },
      { code: 'PER', name: 'Perm Krai', country: 'RU' },
      { code: 'PRI', name: 'Primorsky Krai', country: 'RU' },
      { code: 'PSK', name: 'Pskov Oblast', country: 'RU' },
      { code: 'ROS', name: 'Rostov Oblast', country: 'RU' },
      { code: 'RYA', name: 'Ryazan Oblast', country: 'RU' },
      { code: 'SAK', name: 'Sakhalin Oblast', country: 'RU' },
      { code: 'SE', name: 'North Ossetia-Alania Republic', country: 'RU' },
      { code: 'SAM', name: 'Samara Oblast', country: 'RU' },
      { code: 'SAR', name: 'Saratov Oblast', country: 'RU' },
      { code: 'SMO', name: 'Smolensk Oblast', country: 'RU' },
      { code: 'STA', name: 'Stavropol Krai', country: 'RU' },
      { code: 'SVE', name: 'Sverdlovsk Oblast', country: 'RU' },
      { code: 'TA', name: 'Tambov Oblast', country: 'RU' },
      { code: 'TVE', name: 'Tver Oblast', country: 'RU' },
      { code: 'TY', name: 'Tyumen Oblast', country: 'RU' },
      { code: 'TYU', name: 'Tuva Republic', country: 'RU' },
      { code: 'UD', name: 'Udmurt Republic', country: 'RU' },
      { code: 'ULY', name: 'Ulyanovsk Oblast', country: 'RU' },
      { code: 'VLG', name: 'Vologda Oblast', country: 'RU' },
      { code: 'VOR', name: 'Voronezh Oblast', country: 'RU' },
      { code: 'YAN', name: 'Yamalo-Nenets Autonomous Okrug', country: 'RU' },
      { code: 'YAR', name: 'Yaroslavl Oblast', country: 'RU' },
      { code: 'ZAB', name: 'Zabaykalsky Krai', country: 'RU' }
    ];

    const cities = [
  // Andhra Pradesh
  { name: 'Visakhapatnam', state: 'AP' },
  { name: 'Vijayawada', state: 'AP' },
  { name: 'Guntur', state: 'AP' },

  // Arunachal Pradesh
  { name: 'Itanagar', state: 'AR' },
  { name: 'Naharlagun', state: 'AR' },

  // Assam
  { name: 'Guwahati', state: 'AS' },
  { name: 'Dibrugarh', state: 'AS' },
  { name: 'Silchar', state: 'AS' },

  // Bihar
  { name: 'Patna', state: 'BR' },
  { name: 'Gaya', state: 'BR' },
  { name: 'Bhagalpur', state: 'BR' },

  // Chhattisgarh
  { name: 'Raipur', state: 'CT' },
  { name: 'Bilaspur', state: 'CT' },
  { name: 'Durg', state: 'CT' },

  // Goa
  { name: 'Panaji', state: 'GA' },
  { name: 'Margao', state: 'GA' },
  { name: 'Vasco da Gama', state: 'GA' },

  // Gujarat
  { name: 'Ahmedabad', state: 'GJ' },
  { name: 'Surat', state: 'GJ' },
  { name: 'Vadodara', state: 'GJ' },

  // Haryana
  { name: 'Gurgaon', state: 'HR' },
  { name: 'Faridabad', state: 'HR' },
  { name: 'Panipat', state: 'HR' },

  // Himachal Pradesh
  { name: 'Shimla', state: 'HP' },
  { name: 'Manali', state: 'HP' },
  { name: 'Dharamshala', state: 'HP' },

  // Jharkhand
  { name: 'Ranchi', state: 'JH' },
  { name: 'Jamshedpur', state: 'JH' },
  { name: 'Dhanbad', state: 'JH' },

  // Karnataka
  { name: 'Bangalore', state: 'KA' },
  { name: 'Mysore', state: 'KA' },
  { name: 'Hubli', state: 'KA' },

  // Kerala
  { name: 'Thiruvananthapuram', state: 'KL' },
  { name: 'Kochi', state: 'KL' },
  { name: 'Kozhikode', state: 'KL' },

  // Madhya Pradesh
  { name: 'Bhopal', state: 'MP' },
  { name: 'Indore', state: 'MP' },
  { name: 'Jabalpur', state: 'MP' },

  // Maharashtra
  { name: 'Mumbai', state: 'MH' },
  { name: 'Pune', state: 'MH' },
  { name: 'Nagpur', state: 'MH' },

  // Manipur
  { name: 'Imphal', state: 'MN' },
  { name: 'Thoubal', state: 'MN' },
  { name: 'Churachandpur', state: 'MN' },

  // Meghalaya
  { name: 'Shillong', state: 'ML' },
  { name: 'Tura', state: 'ML' },
  { name: 'Jowai', state: 'ML' },

  // Mizoram
  { name: 'Aizawl', state: 'MZ' },
  { name: 'Lunglei', state: 'MZ' },
  { name: 'Saiha', state: 'MZ' },

  // Nagaland
  { name: 'Kohima', state: 'NL' },
  { name: 'Dimapur', state: 'NL' },
  { name: 'Mokokchung', state: 'NL' },

  // Odisha
  { name: 'Bhubaneswar', state: 'OD' },
  { name: 'Cuttack', state: 'OD' },
  { name: 'Puri', state: 'OD' },

  // Punjab
  { name: 'Ludhiana', state: 'PB' },
  { name: 'Amritsar', state: 'PB' },
  { name: 'Jalandhar', state: 'PB' },

  // Rajasthan
  { name: 'Jaipur', state: 'RJ' },
  { name: 'Jodhpur', state: 'RJ' },
  { name: 'Udaipur', state: 'RJ' },

  // Sikkim
  { name: 'Gangtok', state: 'SK' },
  { name: 'Namchi', state: 'SK' },
  { name: 'Mangan', state: 'SK' },

  // Tamil Nadu
  { name: 'Chennai', state: 'TN' },
  { name: 'Coimbatore', state: 'TN' },
  { name: 'Madurai', state: 'TN' },

  // Telangana
  { name: 'Hyderabad', state: 'TS' },
  { name: 'Warangal', state: 'TS' },
  { name: 'Nizamabad', state: 'TS' },

  // Tripura
  { name: 'Agartala', state: 'TR' },
  { name: 'Udaipur', state: 'TR' },
  { name: 'Dharmanagar', state: 'TR' },

  // Uttar Pradesh
  { name: 'Lucknow', state: 'UP' },
  { name: 'Kanpur', state: 'UP' },
  { name: 'Agra', state: 'UP' },
  { name: 'Noida', state: 'UP' },

  // Uttarakhand
  { name: 'Dehradun', state: 'UK' },
  { name: 'Haridwar', state: 'UK' },
  { name: 'Nainital', state: 'UK' },

  // West Bengal
  { name: 'Kolkata', state: 'WB' },
  { name: 'Asansol', state: 'WB' },
  { name: 'Siliguri', state: 'WB' },
  // Add more cities with their corresponding state code
  // for Russia
  { name: 'Moscow', state: 'MOW' },
  { name: 'Saint Petersburg', state: 'SPE' },
  { name: 'Novosibirsk', state: 'NVS' },
  { name: 'Yekaterinburg', state: 'SVE' },
  { name: 'Nizhny Novgorod', state: 'NIZ' },
  { name: 'Kazan', state: 'TA' },
  { name: 'Chelyabinsk', state: 'CHE' },
  { name: 'Omsk', state: 'OMS' },
  { name: 'Samara', state: 'SAM' },
  { name: 'Rostov-on-Don', state: 'ROS' },
  { name: 'Ufa', state: 'BA' },
  { name: 'Krasnoyarsk', state: 'KYA' },
  { name: 'Voronezh', state: 'VOR' },
  { name: 'Perm', state: 'PER' },
  { name: 'Volgograd', state: 'VGG' },
  { name: 'Krasnodar', state: 'KDA' },
  { name: 'Saratov', state: 'SAR' },
  { name: 'Tolyatti', state: 'TLY' },
  { name: 'Izhevsk', state: 'IJK' },
  { name: 'Ulyanovsk', state: 'ULY' },
  { name: 'Barnaul', state: 'ALT' },
  { name: 'Vladivostok', state: 'PRI' },
  { name: 'Yaroslavl', state: 'YAR' },
  { name: 'Irkutsk', state: 'IRK' },
  { name: 'Tyumen', state: 'TYU' },
  { name: 'Khabarovsk', state: 'KHA' },
  { name: 'Makhachkala', state: 'DA' },
  { name: 'Orenburg', state: 'ORE' },
  { name: 'Novokuznetsk', state: 'KEM' },
  { name: 'Kemerovo', state: 'KEM' },
  { name: 'Ryazan', state: 'RYA' },
  { name: 'Tomsk', state: 'TOM' },
  { name: 'Astrakhan', state: 'AST' },
  { name: 'Penza', state: 'PNZ' },
  { name: 'Lipetsk', state: 'LIP' },
  { name: 'Tula', state: 'TUL' },
  { name: 'Kirov', state: 'KIR' },
  { name: 'Cheboksary', state: 'CU' },
  { name: 'Kaliningrad', state: 'KGD' },
  { name: 'Bryansk', state: 'BRY' },
  { name: 'Ivanovo', state: 'IVA' },
  { name: 'Magnitogorsk', state: 'CHL' },
  { name: 'Sochi', state: 'KDA' },
  { name: 'Kursk', state: 'KRS' },
  { name: 'Tver', state: 'TVE' },
  { name: 'Stavropol', state: 'STA' },
  { name: 'Nizhny Tagil', state: 'SVE' },
  { name: 'Arkhangelsk', state: 'ARK' },
  { name: 'Kurgan', state: 'KGN' },
  { name: 'Belgorod', state: 'BEL' },
  { name: 'Kaluga', state: 'KLU' },
  { name: 'Vladimir', state: 'VLA' },
  { name: 'Smolensk', state: 'SMO' },
  { name: 'Chita', state: 'ZAB' },
  { name: 'Orsk', state: 'ORE' },
  { name: 'Bratsk', state: 'IRK' },
  { name: 'Novorossiysk', state: 'KDA' },
  { name: 'Taganrog', state: 'ROS' },
  { name: 'Engels', state: 'SAR' },
  { name: 'Rybinsk', state: 'YAR' },
  { name: 'Podolsk', state: 'MOW' },
  { name: 'Shakhty', state: 'ROS' },
  { name: 'Votkinsk', state: 'Udm' },
  { name: 'Kyzyl', state: 'Tyv' },
 ];


    // Populate countries select input
    const countriesSelect = document.getElementById('countries');
    countries.forEach(country => {
      const option = document.createElement('option');
      option.value = country.code;
      option.textContent = country.name;
      countriesSelect.appendChild(option);
    });

    // Handle change event for countries to populate states
    countriesSelect.addEventListener('change', function() {
      const selectedCountry = this.value;
      const statesSelect = document.getElementById('states');
      statesSelect.innerHTML = '<option value="">Select a state</option>';

      const filteredStates = states.filter(state => state.country === selectedCountry);
      filteredStates.forEach(state => {
        const option = document.createElement('option');
        option.value = state.code;
        option.textContent = state.name;
        statesSelect.appendChild(option);
      });
    });

    // Handle change event for states to populate cities (similar logic)
    document.getElementById('states').addEventListener('change', function() {
      const selectedState = this.value;
      const citiesSelect = document.getElementById('cities');
      citiesSelect.innerHTML = '<option value="">Select a city</option>';

      const filteredCities = cities.filter(city => city.state === selectedState);
      filteredCities.forEach(city => {
        const option = document.createElement('option');
        option.value = city.name;
        option.textContent = city.name;
        citiesSelect.appendChild(option);
      });
    });
  });
</script>
@endsection 